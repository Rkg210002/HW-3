# Average Function Testing Assignment

## Structure
- `src/Average.java`: Contains the implementation of the average function.
- `test/AverageTest.java`: Contains JUnit tests for functional, partition, and boundary value testing.

## Instructions
1. Import into Eclipse as a Java project.
2. Use EclEmma to run the test suite with coverage analysis.
3. Ensure all branches are covered and tests pass.

## Fault Injection Test (for section f)
You can simulate a bug by changing `Math.min(k, list.length)` to `Math.max(k, list.length)` in `Average.java` and observe test failures.

## Author
Ritvik